<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
                $sql = 'CREATE DATABASE mydatabase1';

        $connection = mysqli_connect("localhost","root","",$sql);
        $table = 'CREATE TABLE employees(id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(30) NOT NULL, email VARCHAR(30) NOT NULL, contact INT(15))';

            if(mysqli_query($connection,$table)){
                echo "connected";
            }
            else{
                echo "Error";
            }

                 
            
            ?>
    
</body>
</html>