<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'mydb');

if(isset($_POST['delete']))
{
    $id = $_POST['id'];
    
 $query= "  DELETE employee ,empadd from employee inner join empadd on empadd.emp_id=employee.id where employee.id='$id'";
 $query_run = mysqli_query($connection, $query);
 if($query_run){
    echo '<script> alert("DATA DELETE");</script>';

 }

/*$query="DELETE  FROM `employee` WHERE id= '$id'";
$query_run = mysqli_query($connection, $query);
if($query_run){
    $emp_id = mysqli_insert_id($connection);
     
$sql = "DELETE FROM `empadd` WHERE id = emp_id";

$result = mysqli_query($connection,$sql);
if($result){

echo '<script> alert("DATA DELETE");</script>';
}
}else{
    echo '<script>alert("DATA NOT DELETE");</script>';
}
*/
}

?>