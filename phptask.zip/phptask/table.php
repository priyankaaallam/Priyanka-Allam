<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

    <title>Document</title>
</head>
<body>
<div class="container">
        <div class="jumbotron">
            <h2>PHP - CRUD </h2>
            <hr>
<div class="row">
    <a href="insetdata.php" class="btn btn-success" style="margin-left:80%; width:150px">ADD DATA </a>
    
</div>
</br>
            <?php
            $connection = mysqli_connect("localhost","root","");
            $db = mysqli_select_db($connection,'mydb');
            $query = "SELECT * FROM `empadd` INNER JOIN `employee` ON `empadd`.`emp_id` = `employee`.`id`";
            $query_run = mysqli_query($connection,$query);
            ?>
<table class="table table-bordered" style="background-color:gray;">
<thead class="table-dark">
    <tr>
        <th>ID</th>
        <TH>Emp ID</TH>
        <th>NAME</th>
        <th>EMAIL</th>
        <th>CONTACT</th>
        <th>ADDRESS</th>
        <th>CITY</th>
        <th>PINCODE</th>
        <th>EDIT</th>
        <TH>DELETE</TH>
</tr>

            <?php
            if($query_run){
                 while($row = mysqli_fetch_array($query_run)){
                 ?>
                 <tbody>
                    <tr>
                    <th><?php echo $row['id']; ?></th>
                    <th><?php echo $row['emp_id']; ?></th>

                        <th><?php echo $row['name']; ?></th>

                        <th><?php echo $row['email']; ?></th>
                        <th><?php echo $row['contact'];  ?></th>
                        <th><?php echo $row['address']; ?></th>
                        <th><?php echo $row['city']; ?></th>
                        <th><?php echo $row['pincode']; ?></th>
                        <form action="updatedata.php" method="post">
                            <input type="hidden" name="id" value= "<?php echo $row['id'] ?>">
         <th><input type="submit" name="edit" class="btn btn-success" value="EDIT"></th>
                        </form>

                        <form action="delete.php" method="post">

                       <input type ="hidden" name="id" value= "<?php echo $row['id'] ?>">
                        <th><input type="submit" name="delete" class="btn btn-danger" value="DELETE"></th>
                 </form>
                        
                    </tr>
                 </tbody>
                 <?php
        
                 }
            }
            else
            {
                   echo "no record found";
            }
            
            
            ?>
            </table>
        </div>
</div>

</body>
</html>
</body>
</html>