<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
       $servername = "localhost";
       $username = "root";
       $password = "";
       $db = "mydatabase1";

       $connection = mysqli_connect($servername,$username,$password,$db);

 $sql = "INSERT INTO employee (name,email,contact) VALUES ( 'priyanka','priya@gmail.com',6281888230);";
 $sql .= "INSERT INTO employee (name,email,contact) VALUES ('sanvi','sanvi@gmail.com',9999999999);";
 $sql .= "INSERT INTO employee (name,email,contact) VALUES ('hello','php@gmail.com',9098877666);";
 $add = "INSERT INTO employeeaddress (address,city,pincode) VALUES ( 'suryapet','suryapet',508213);";
 $add .= "INSERT INTO employeeaddress (address,city,pincode) VALUES ('suryapet','suryapet',500032);";

 if(mysqli_multi_query($connection,$add))
{
    $lastid = mysqli_insert_id($connection);
    echo "Last insert id is $lastid ";
 }
 else
 {
    echo "failed";
 }


?>
</body>
</html>