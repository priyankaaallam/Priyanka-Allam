<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="jumbotron">
<h2>PHP - ADD DATA</h2>
<HR>
<form action="" method="post">
<div class="form-group">
<label for=""> NAME</label>
<INPUT type="text" name="name" class="form-control" placeholder="Enter Your Name">
</div>
<br>

<div class="form-group">
<label for="">EMAIL</label>
<INPUT type="text" name="email" class="form-control" placeholder="Enter Your Email ">
</div>
<br>
<div class="form-group">
<label for="">CONTACT</label>
<INPUT type="text" name="contact" class="form-control" placeholder="Enter Contact number">
</div>
<br>

<div class="form-group">
<label for=""> ADDRESS</label>
<INPUT type="text" name="address" class="form-control" placeholder="Enter Your Address">
</div>
<br>
<div class="form-group">
<label for="">CITY</label>
<INPUT type="text" name="city" class="form-control" placeholder="Enter Your City">
</div>
<br>
<div class="form-group">
<label for=""> PINCODE</label>
<INPUT type="text" name="pincode" class="form-control" placeholder="Enter Your Pincode">
</div>
<br>
<button type="submit" name="insert" class="btn btn-primary">Save Data</button>
<a href="table.php" class="btn btn-danger">CANCEL</a>
</form>

        </div>
    </div>
    
</body>
</html>
<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'mydb');
if(isset($_POST['insert'])){
 $name = $_POST['name'];
 $email = $_POST['email'];
 $contact = $_POST['contact'];
 $emp_id = $_POST['emp_id'];
 $address = $_POST['address'];
 $city = $_POST['city'];
 $pincode = $_POST['pincode'];

 
 $query="INSERT INTO `employee`(`name`,`email`,`contact`) VALUES ('$name','$email','$contact')";
$query_run = mysqli_query($connection, $query);
if($query_run){
    $emp_id = mysqli_insert_id($connection);
     
$sql = "INSERT INTO `empadd`(`emp_id`,`address`,`city`,`pincode`) VALUES ('$emp_id','$address','$city','$pincode')";

$result = mysqli_query($connection,$sql);
if($result){

echo '<script> alert("DATA SAVED");</script>';
}
}else{
    echo '<script>alert("DATA NOT SAVED");</script>';
}
}
?>
