<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

    <title>Document</title>
</head>
<body>
<div class="container">
    <div class="jumbotron">
        <h2>Employee Table</h2>
        <hr>
        <?php
        $connection = mysqli_connect("localhost","root","");
        $db = mysqli_select_db($connection,'mydatabase1');
        $query = "SELECT * FROM employee";
        $query_run = mysqli_query($connection,$query);
        ?>
        <table class = "table table-bordered" style="backgroung-color:gray">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>NAME</th>
                <th>EMAIL</th>
                <th>CONTACT</th>



            </tr>
            <?php
            if($query_run)
            {
                while($row = mysqli_fetch_array($query_run))
                {
                ?>
                <tbody>
                    <tr>
                        <th><?php echo $row['id']; ?></th>
                        <th><?php echo $row['name'];?></th>
                        <th><?php echo $row['email']; ?></th>
                        <th><?php echo $row['contact']; ?></th>
                    </tr>
                </tbody>
                     <?php
            }
    }
    else
    {
      echo "no record found";
}
?>
        </table>
<?php 
        $query = "SELECT * FROM employeeaddress";
        $query_run = mysqli_query($connection,$query);
        ?>
        <table class = "table table-bordered" style="backgroung-color:gray">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>ADDRESS</th>
                <th>CITY</th>
                <th>PINCODE</th>
            </tr>
            <?php
            if($query_run)
            {
                while($row = mysqli_fetch_array($query_run))
                {
                ?>
                <tbody>
                    <tr>
                        <th><?php echo $row['id']; ?></th>
                        <th><?php echo $row['address'];?></th>
                        <th><?php echo $row['city']; ?></th>
                        <th><?php echo $row['pincode']; ?></th>
                    </tr>
                </tbody>
            
            <?php
            }
    }

else
{
      echo "no record found";
}


?>
       
        </table>*/

        </div>
</div>
</body>
</html>