<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

    <title>Document</title>
</head>
<body>
    <?php
     $connection = mysqli_connect('localhost','root','');
     $db = mysqli_select_db($connection,'mydb');
        $query = "SELECT * FROM `empadd` INNER JOIN `employee` ON `empadd`.`emp_id` = `employee`.`id`";

     $query_run = mysqli_query($connection,$query);
     if($query_run){
       while($row =mysqli_fetch_array($query_run))
       {
?>
<div class="container">
    <div class="jumbotron">

    <H2>PHP - UPDATE</H2>
    <hr>

    <form action="" method="post">
        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
        <div class="form-group">
<label for="">NAME</label>
<INPUT type="text" name="name" class="form-control" value="<?php echo $row['name'] ?>" placeholder="Enter Your Name">
</div>
<br>
<div class="form-group">
<label for="">EMAIL</label>
<INPUT type="text" name="email" class="form-control" value="<?php echo $row['email'] ?>" placeholder="Enter Email ID">
</div>
<br>
<div class="form-group">
<label for="">CONTACT</label>
<INPUT type="text" name="contact" class="form-control" value="<?php echo $row['contact'] ?>" placeholder="Enter Contact number">
</div>
<br>
<div class="form-group">
    <label for="">ADDRESS</label>
    <input type="text" name="address" class="form-control" value="<?php echo $row['address'] ?>" placeholder="Enter Address">
    </div>
    <br>
    <div class="form-group">
    <label for="">CITY</label>
    <input type="text" name="city" class="form-control" value="<?php echo $row['city'] ?>" placeholder="Enter City">
    </div>
    <br>
    <div class="form-group">
    <label for="">PINCODE</label>
    <input type="text" name="pincode" class="form-control" value="<?php echo $row['pincode'] ?>" placeholder="Enter Pincode">
    </div>
    <br>
<button type="submit" name="update" class="btn btn-primary">UPDATE DATA</button>
<a href="table.php" class="btn btn-danger">CANCEL</a>
</form>
<?php
if(isset($_POST['update'])){
$emp_id= $_POST['emp_id'];
$name = $_POST['name'];
$email = $_POST['email'];
$contact = $_POST['contact'];
$address = $_POST['address'];
$city = $_POST['city'];


$query="UPDATE employee SET name='$name', email='$email',contact='$contact' WHERE id = '$id'";

//$query= "  UPDATE  employee ,empadd from employee inner join empadd on empadd.emp_id=employee.id where employee.id='$id'";
$query_run = mysqli_query($connection, $query);
if($query_run){
   
     
$sql ="UPDATE empadd SET address='$address',city='$city',pincode='$pincode' WHERE emp_id='$id' ";

$result = mysqli_query($connection,$sql);
if($result){

echo '<script> alert("DATA UPDATED");</script>';
}
}
else{
    echo '<script>alert("DATA NOT SAVED");</script>';

}
}
       }
    }

?>

    </div>
</div>
 
</body>
</html>