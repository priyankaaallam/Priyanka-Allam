<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
     $connection = mysqli_connect('localhost','root','');
     $db = mysqli_select_db($connection,'mydb');
   $query =  "SELECT `empadd`.`emp_id`,`empadd`.`address`,`employee`.`name` FROM `empadd` INNER JOIN `employee` ON `empadd`.`emp_id`=`employee`.`id`;"
     $result =mysqli_query($connection,$query);
if($result){
    while($row = mysqli_fetch_array($result)){
        echo $row['emp_id'];
        echo $row['name'];
        echo $row['address'];
    }
}
      
     ?>
     
</body>
</html>